# Handoff: PCAM 9 OJK — Quiz Practice & Question Bank

## Overview
An internal exam-practice platform for PCAM 9 (OJK), covering Accounting, Audit, Financial Statement Analysis, and Data Analysis. Two modules:
1. **Assessment** — the student-facing exam: one question per screen, sidebar navigation, flag-for-review, autosave, review/summary before submit, and a scored results page with answer key.
2. **Question Bank** — a read-only, internal view of the full question repository, filterable by section, showing correct answers.

## About the Design Files
The files in this bundle are **design references built in HTML** (a prototyping tool's component format — see "Files" below for a note on syntax). They demonstrate exact visual design and full interaction behavior, but are not production code to copy directly. The task is to **recreate this design in the target codebase's actual stack** (React, Vue, native, etc. — whichever the project uses, or the best choice if none exists yet), using that stack's own component/state patterns.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and states below are exact — implement pixel-for-pixel. The question content itself (40 sample questions) is placeholder data standing in for a planned ~200-question bank; the data shape is what matters, not these specific questions.

## Screens / Views

### 1. Assessment — Question view (default view, `Quiz Practice.dc.html`)
**Purpose:** answer one multiple-choice question at a time.
**Layout:** full-height column. Top: 68px header, full width, `border-bottom: 2px solid rgba(32,30,29,0.4)`, background `#f3f2f2`, padding `0 32px`, flex row `justify-content: space-between`.
- Left: brand "PCAM 9 OJK" (18px/800) + subtitle "Class Assessment Practice" (13px, `#605d5d`), gap 14px, `align-items: baseline`.
- Right: progress text "{answered}/{total} answered" (12.5px/600, `#605d5d`) above a 150×4px track (`#d7d3d3`) with a fill bar in `#2F6FED` scaled to `% answered`; then an outline button "Review & Submit"; then a text link "Question Bank →" (`#1d4ed8`, 13px/700) to the other module.

Below header: flex row, no max-height, two panes:
- **Sidebar** (300px fixed, `border-right: 2px solid rgba(32,30,29,0.4)`, padding `24px 20px`, scrollable): heading "Question List" (16px/800); a legend row (4 items, 11.5px, gap 14px, `border-bottom: 2px solid divider`, padding-bottom 18px) — swatches for Unanswered / Answered / Active / Flagged (see Design Tokens); then one block per section, separated by a `2px solid divider` top rule (except the first), each with an uppercase 11.5px/700 section title (color `#7d7979`, letter-spacing .06em) and a grid of number tiles (`grid-template-columns: repeat(N,1fr)`, gap 8px, N configurable — default 5).
- **Main pane** (flex:1, scrollable, padding 44px 32px, content centered, max-width 660px): a surface panel (`background: #eae9e9`, padding `40px 44px`, no border-radius) containing:
  - a 4×64px blue tick bar (`#2F6FED`) as a decorative marker
  - a header row: eyebrow "Question {n} · {Section Title}" (12.5px/700 uppercase, `#1d4ed8`, letter-spacing .06em) next to a "Flag for review" toggle button (see states below)
  - question text (25px/800, line-height 1.4)
  - 4 answer options, each a full-width clickable row (padding `16px 18px`, gap 14px) with a 16px circular radio marker + label text (15.5px)
  - below the panel: Previous / Next buttons, `justify-content: space-between`, margin-top 28px

### 2. Assessment — Review / Summary view
**Purpose:** check answered/unanswered status for all questions before final submit.
**Layout:** same header pattern, subtitle "Summary before submit", right side just a "Back to Questions" outline button. Body: centered column, max-width 820px, padding `40px 32px 24px`.
- Title "Answer Summary" (26px/800) + helper text (14.5px, `#605d5d`)
- A two-cell stat bar (`border: 1px solid divider`, no radius): "{answered}/{total}" (30px/800) "Questions answered"; second cell "{unanswered}" "Not answered" — this cell's background/text switch to the blue tint (`#eaf1fd` / `#1d4ed8`) when count > 0, else transparent/ink.
- Per-section number-tile grids (46px tiles, same status coloring as sidebar), each section separated by a 2px divider.
- Sticky footer (`border-top: 2px solid divider`, padding `18px 32px`): "Back to Questions" outline button (left) + "Submit Quiz" primary button (right, disabled/dimmed to 45% opacity if the "require all answered" setting is on and questions remain unanswered).

### 3. Assessment — Results view
**Purpose:** show score and (optionally) the answer key after submit.
**Layout:** header subtitle "Results", right side a "Restart" ghost text button (clears all progress). Body centered, max-width 760px, padding `44px 32px 60px`.
- Big score row: "{percent}%" (64px/800) next to "{correct} of {total} correct" (15px, `#605d5d`), then a 4×full-width blue divider bar.
- If answer key is enabled: per-section list, each section header (12px/700 uppercase, `#7d7979`, top-bordered `2px solid divider`), then one row per question (padding `16px 0`, `border-bottom: 1px solid rgba(32,30,29,0.15)`, flex row space-between): left side shows "{n}. {question text}" (15px/600) + "Your answer: {text}" (13.5px, `#444141`) + if wrong, "Correct answer: {text}" below it; right side a status tag — "Correct" (green tint), "Incorrect" (red tint), or "Not answered" (outlined neutral).

### 4. Question Bank — Browse view (`Question Bank.dc.html`)
**Purpose:** internal, read-only reference list of the full question repository.
**Layout:** header (same 68px pattern) — subtitle "Question Bank", right side "{total} questions in bank" text + "← Assessment" link back to the other module.
- Filter tab row (padding `20px 32px`, `border-bottom: 2px solid divider`, gap 8px, wraps): "All (N)" plus one tab per section, each a `1px` bordered button (blue-filled when active, outline when not, `white-space: nowrap`).
- Body: centered list, max-width 860px, padding `36px 32px 60px`. One block per visible section (title + "{count} questions in bank · random draw: {n} per session" meta line), then one row per question (padding `20px 0`, 1px hairline row divider): "Question {n}" label (11px, `#7d7979`), question text (16px/600), then each option on its own line with an 8px square marker + text — the correct option's marker/text render in green (`#15803d`, bold) with a small "Correct" tag, unless the "show correct answers" setting is off.

## Interactions & Behavior
- **Sidebar/summary number tiles**: click any tile to jump straight to that question, regardless of section or order.
- **Previous / Next**: sequential navigation; "Next" becomes "Review & Submit" on the last question.
- **Flag for review**: toggles a per-question flag independent of answered state; shows as a small amber corner badge on the tile in both the sidebar and the review grid.
- **Autosave**: every answer, flag, and navigation change is persisted to `localStorage` (key `pcam9-ojk-quiz-progress-v1`) and restored on page load — so a refresh doesn't lose progress. "Restart" clears this key.
- **Submit gating**: a "require all answered" setting (off by default) blocks Submit while any question is unanswered.
- **Question Bank filter tabs**: click a tab to show only that section's questions, or "All" to show everything; purely client-side filtering, no navigation.
- No timer. No animations beyond instant hover/selection state changes.

### States
- Radio option: default (`1px solid transparent` border, transparent bg) → hover (light grey tint `#eae7e7`, only when not selected) → selected (`1px solid #2F6FED` border, `#eaf1fd` bg, filled blue dot with a light inset ring).
- Buttons: primary (blue fill, white text) / outline (transparent, divider border, ink text) / ghost (no border, blue text). Disabled state = 45% opacity + `not-allowed` cursor.
- Number tile: unanswered (`#f8f4f4` bg, `#444141` text, 1px divider border) / answered (`#15803d` bg, white text) / current (adds a 2px `#2F6FED` border regardless of answered state) / flagged (adds an absolute-positioned 10×10px amber badge, top/right -5px, `#d97706` bg with a light border).

## State Management
**Assessment module:** `current` (index into the flat question list), `answers` (map of question-index → chosen option index), `flagged` (map of question-index → boolean), `view` (`'quiz' | 'review' | 'submitted'`), `dataLoaded` (question data loads asynchronously from the shared data file). Derived: `answeredCount`, `unansweredCount`, `progressPercent`, `scoreCorrect`, `scorePercent`.
**Question Bank module:** `activeFilter` (`'all'` or a section index), `dataLoaded`.
**Persistence:** `answers`, `flagged`, and `current` are written to `localStorage` after every change and restored on mount.

## Design Tokens
- **Background** `#f3f2f2` · **Surface (panels)** `#eae9e9` · **Ink text** `#201e1d`
- **Primary blue** `#2F6FED` (buttons, active state, links/eyebrow text use the deeper `#1d4ed8` for AA contrast on light bg, selected-option tint `#eaf1fd`)
- **Success green** `#15803d` (answered tiles, "Correct" tag/text; tint `#eafaf1`)
- **Error red** `#b91c1c` (incorrect tag text; tint `#fef2f2`)
- **Flag amber** `#d97706` (flag badge/button; tint `#fff7ed`)
- **Neutrals**: `#605d5d` (secondary text), `#7d7979` (section labels), `#444141` (body text on light fills), `#f8f4f4` (unanswered tile fill), `#d7d3d3` (progress track)
- **Dividers**: `rgba(32,30,29,0.4)` for structural 2px rules, `rgba(32,30,29,0.15)` for 1px row hairlines
- **Typography**: Archivo, weights 400/600/800 throughout (headings and labels use 800). Sizes range 11px (micro labels) → 64px (score display).
- **Radius**: 0 everywhere except radio dots and the flag badge, which are circles (`border-radius: 50%`).
- **Spacing**: header height 68px; sidebar width 300px; content max-widths 660px (question), 820px (summary), 760px (results), 860px (bank); consistent 32px page-edge padding.

## Assets
No images/icons. Archivo loaded from Google Fonts.

## Configurable behavior (exposed as tweakable props in the prototype)
- `showAnswerKey` (bool, default true) — show/hide the answer-key breakdown on the results page.
- `requireAllAnswered` (bool, default false) — block Submit until every question is answered.
- `numbersPerRow` (int, default 5) — sidebar tile grid density.
- `showCorrectAnswers` (bool, default true, Question Bank only) — show/hide correct-answer highlighting.
- `drawPerSection` (int, default 10, Question Bank only) — informational "random draw per session" number shown per section; not yet wired to real random selection logic in the Assessment module (flagged as a follow-up: implement actual per-session random sampling from the bank once question count scales up).

## Files
- `Quiz Practice.dc.html` — Assessment module (all three views)
- `Question Bank.dc.html` — Question Bank module
- `quiz-data.js` — shared question data (plain ES module, `export const sectionsData = [...]`), imported by both modules via dynamic `import()`. This is the file to swap out for a real API/database call in production — its shape (`{ title, questions: [{ text, options, correct }] }`) is the contract to preserve.

**Note on file syntax**: the `.dc.html` files use a prototyping tool's own template syntax (`{{ }}` bindings, `<sc-for>`/`<sc-if>` loops/conditionals, a `class Component extends DCLogic` logic block) — this is not standard HTML/JS and should not be copied verbatim. Treat the rendered behavior and the descriptions above as the spec; reimplement in the target stack's own components/state.
